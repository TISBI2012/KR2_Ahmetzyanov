﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Kr2_Ahmetzyanov.Model;

namespace Kr2_Ahmetzyanov
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static KR2_AhmetzyanovEntities DB = new KR2_AhmetzyanovEntities();
    }
}
